import {
  ContainerBuilder,
  SectionBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  ThumbnailBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  SeparatorSpacingSize,
  type Client,
} from "discord.js";
import type { ITicket } from "../models/Ticket.js";
import { CATEGORIES, CATEGORY_ORDER } from "../constants/categories.js";
import { config } from "../config.js";

// ─── HELPERS DE FECHA ──────────────────────────────────────────────────────────
export function getFooterTimestamp(): string {
  const now = new Date();
  const date = now.toLocaleDateString("es-ES", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
  const time = now.toLocaleTimeString("es-ES", {
    hour: "2-digit",
    minute: "2-digit",
  });
  return `${date} · ${time}`;
}

// ─── PRIORIDAD DISPLAY ─────────────────────────────────────────────────────────
export const PRIORITY_DISPLAY: Record<string, { label: string }> = {
  low:      { label: "Baja"    },
  medium:   { label: "Media"   },
  high:     { label: "Alta"    },
  critical: { label: "Critica" },
};

// ─── PANEL PRINCIPAL (COMPONENTS V2 CONTAINER) ────────────────────────────────
export function buildPanelContainer(client: Client, guildIconUrl?: string): ContainerBuilder {
  const iconUrl = guildIconUrl ?? client.user?.displayAvatarURL({ size: 256 }) ?? "";

  // Opciones del select menu
  const options = CATEGORY_ORDER.map(catId => {
    const cat = CATEGORIES[catId]!;
    return new StringSelectMenuOptionBuilder()
      .setLabel(cat.label)
      .setDescription(cat.description)
      .setValue(catId)
      .setEmoji(cat.emoji);
  });

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId("ticket:select_category")
    .setPlaceholder("Elige la categoría que mejor describa tu consulta...")
    .setMinValues(1)
    .setMaxValues(1)
    .addOptions(options);

  const selectRow = new ActionRowBuilder<StringSelectMenuBuilder>()
    .addComponents(selectMenu);

  const headerText =
    "# 🆘 Soporte & Ayuda\n**Bienvenid@** al apartado de ayuda y atencion a los usuarios de forma **OOC**, revisa con lo que podemos ayudarte y auxiliarte para tu mejor atencion.";

  const categoriesText = [
    "🛡️ **Reportar**\nInforma sobre un jugador que haya incumplido las normas del servidor.",
    "👮 **Reportar Staff**\nSi tuviste un problema con un miembro del equipo, cuéntanos qué ocurrió.",
    "📋 **Petición de Rol**\nSolicita un rol y adjunta las pruebas o requisitos necesarios.",
    "🔒 **Reporte Confidencial**\nEnvía un reporte de forma confidencial cuando la situación lo requiera.",
    "🎭 **Remover Rol**\nSolicita que se retire un rol de tu cuenta o de otro usuario cuando corresponda.",
    "💵 **IRL**\nSoporte para compras realizadas con dinero real o Robux.",
    "🎁 **Reclamar Sorteo**\nReclama el premio de un sorteo que hayas ganado.",
    "🤝 **Empresas y Facciones**\nCrea una empresa o facción, o solicita ayuda relacionada con una existente.",
    "📦 **Otros**\nSi tu consulta no encaja en ninguna categoría, abre un ticket aquí.",
    "💬 **Dudas Generales**\nHaz cualquier pregunta sobre el servidor y con gusto te ayudaremos.",
  ].join("\n\n");

  const recuerdaText = [
    "**❗RECUERDA**",
    "* Usa el sistema con madurez, cualquier chiste & broma sera una sancion directa sin apelacion.",
    "* Recuerda que todo reporte puede variar en su tiempo de respuesta, no hagas **ping a moderadores.**",
    "* Recuerda mantener una actitud deacuerdo a la normativa especifica dentro del servidor y en atención con la moderacion.",
  ].join("\n");

  return new ContainerBuilder()
    .setAccentColor(0x5865f2) // Azul-morado Blurple
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(headerText)
        )
        .setThumbnailAccessory(
          new ThumbnailBuilder().setURL(iconUrl)
        )
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(categoriesText)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(recuerdaText)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    )
    .addActionRowComponents(selectRow)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# MEXERP System · ${getFooterTimestamp()}`)
    );
}


// ─── HELPER COLOR ALEATORIO ───────────────────────────────────────────────────
export function getRandomColor(): number {
  const colors = [
    0x7c3aed, // Morado
    0x3b82f6, // Azul
    0x10b981, // Verde
    0xf59e0b, // Naranja
    0xec4899, // Rosa
    0x8b5cf6, // Violeta
    0x06b6d4, // Cyan
    0x10b981, // Esmeralda
  ];
  return colors[Math.floor(Math.random() * colors.length)]!;
}

// ─── CONTAINER DEL TICKET ─────────────────────────────────────────────────────
export function buildTicketContainer(
  ticket: ITicket,
  client: Client,
  guildIconUrl?: string,
): ContainerBuilder {
  const iconUrl = guildIconUrl ?? client.user?.displayAvatarURL({ size: 256 }) ?? "";
  const cat = CATEGORIES[ticket.category]!;

  const staffPing = `<@&${config.staffRoleId}>`;
  const headerText = `# ${cat.emoji} ${cat.label} - MEXERP\nHola, tu solicitud esta creada, espera a un miembro del staff para ser **atendid@** ${staffPing}`;

  // Información de tu Ticket
  const infoLines: string[] = ["📝 **Información de tu Ticket:**"];
  const imageUrls: string[] = [];

  // Campos del modal (solo si el usuario rellenó información)
  for (const [key, value] of ticket.modalData) {
    if (!value || !value.trim()) continue; // Si es opcional y no puso nada, no aparece
    const fieldDef = cat.fields.find(f => f.customId === key);
    const label = fieldDef?.label ?? key;

    const lines = value.split("\n").map(l => l.trim()).filter(Boolean);
    const urls = lines.filter(l => l.startsWith("attachment://") || l.startsWith("http://") || l.startsWith("https://"));

    if (urls.length > 0) {
      imageUrls.push(...urls);
      infoLines.push(`**${label}:**\n* 🖼️ ${urls.length} archivo(s) adjunto(s)`);
    } else {
      infoLines.push(`**${label}:**\n* ${value.trim()}`);
    }
  }

  // Usuario
  infoLines.push(`**Usuario:**\n* <@${ticket.ownerId}>`);

  // Registro (Fecha)
  const openedTimestamp = Math.floor(new Date(ticket.openedAt).getTime() / 1000);
  infoLines.push(`**Registro (Fecha):**\n* <t:${openedTimestamp}:f>`);

  // Estado
  const statusText = ticket.claimedBy
    ? `* 🟢 Atendido por <@${ticket.claimedBy}>`
    : `* 🟡 Espera de atencion`;
  infoLines.push(`**Estado:**\n${statusText}`);

  // Botón Reclamar con estado
  const claimBtn = new ButtonBuilder()
    .setCustomId(`ticket:claim:${ticket.channelId}`)
    .setEmoji("✅");

  if (ticket.claimedBy) {
    claimBtn
      .setLabel(`Reclamado por ${ticket.claimedByTag ?? "Staff"}`)
      .setStyle(ButtonStyle.Success)
      .setDisabled(true);
  } else {
    claimBtn
      .setLabel("Reclamar")
      .setStyle(ButtonStyle.Primary)
      .setDisabled(false);
  }

  const claimRow = new ActionRowBuilder<ButtonBuilder>().addComponents(claimBtn);

  // Select menu con las opciones de Cerrar / Transcript
  const managementSelect = new StringSelectMenuBuilder()
    .setCustomId(`ticket:management:${ticket.channelId}`)
    .setPlaceholder("Opciones de gestión...")
    .setMinValues(1)
    .setMaxValues(1)
    .addOptions(
      new StringSelectMenuOptionBuilder()
        .setLabel("Cerrar")
        .setValue("close")
        .setEmoji("🔒")
        .setDescription("Cierra este ticket"),
      new StringSelectMenuOptionBuilder()
        .setLabel("Transcript")
        .setValue("transcript")
        .setEmoji("📰")
        .setDescription("Genera la transcripción de este ticket"),
    );

  const selectRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(managementSelect);

  const container = new ContainerBuilder()
    .setAccentColor(getRandomColor()) // Color aleatorio
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(headerText)
        )
        .setThumbnailAccessory(
          new ThumbnailBuilder().setURL(iconUrl)
        )
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(infoLines.join("\n"))
    );

  // Si hay imágenes subidas, agregamos MediaGallery arriba del botón Reclamar y la línea separadora
  if (imageUrls.length > 0) {
    console.log("[CONTAINER] Agregando imágenes a MediaGallery:", imageUrls);
    const galleryItems = imageUrls.slice(0, 10).map(url => ({ media: { url } }));
    container.addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    );
    (container as any).components.push({
      type: 12, // ComponentType.MEDIA_GALLERY
      items: galleryItems,
      toJSON() {
        return {
          type: 12,
          items: galleryItems,
        };
      },
    });
  }

  container
    .addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    )
    .addActionRowComponents(claimRow)
    .addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    )
    .addActionRowComponents(selectRow)
    .addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# MEXERP System · ${getFooterTimestamp()}`)
    );

  return container;
}

// ─── CONTAINER DE LOG ─────────────────────────────────────────────────────────
export function buildLogContainer(
  action: string,
  description: string,
  fields: { name: string; value: string }[],
  client: Client,
): ContainerBuilder {
  const avatarUrl = client.user?.displayAvatarURL({ size: 256 }) ?? "";
  const fieldsText = fields.map(f => `**${f.name}:** ${f.value}`).join("\n");

  return new ContainerBuilder()
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `## ${action}\n${description}`
          )
        )
        .setThumbnailAccessory(
          new ThumbnailBuilder().setURL(avatarUrl)
        )
    )
    .addSeparatorComponents(
      new SeparatorBuilder()
        .setSpacing(SeparatorSpacingSize.Small)
        .setDivider(true)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(fieldsText)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `-# MEXERP System · ${getFooterTimestamp()}`
      )
    );
}

// ─── CONTAINER DE ERROR ───────────────────────────────────────────────────────
export function buildErrorContainer(
  message: string,
  client: Client,
): ContainerBuilder {
  const avatarUrl = client.user?.displayAvatarURL({ size: 256 }) ?? "";

  return new ContainerBuilder()
    .setAccentColor(0xef4444) // Rojo — Error / Sin Permisos
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`## ❌ Permisos Insuficientes / Error\n${message}`)
        )
        .setThumbnailAccessory(
          new ThumbnailBuilder().setURL(avatarUrl)
        )
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `-# MEXERP System · ${getFooterTimestamp()}`
      )
    );
}

// ─── CONTAINER DE EXITO ───────────────────────────────────────────────────────
export function buildSuccessContainer(
  title: string,
  message: string,
  client: Client,
): ContainerBuilder {
  const avatarUrl = client.user?.displayAvatarURL({ size: 256 }) ?? "";

  return new ContainerBuilder()
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`## ${title}\n${message}`)
        )
        .setThumbnailAccessory(
          new ThumbnailBuilder().setURL(avatarUrl)
        )
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `-# MEXERP System · ${getFooterTimestamp()}`
      )
    );
}

// ─── CONTAINER DE PRIORIDAD ───────────────────────────────────────────────────
export function buildPrioritySelectContainer(
  channelId: string,
  client: Client,
): ContainerBuilder {
  const avatarUrl = client.user?.displayAvatarURL({ size: 256 }) ?? "";

  const lowBtn = new ButtonBuilder()
    .setCustomId(`ticket:setpriority:${channelId}:low`)
    .setLabel("Baja")
    .setStyle(ButtonStyle.Secondary);

  const medBtn = new ButtonBuilder()
    .setCustomId(`ticket:setpriority:${channelId}:medium`)
    .setLabel("Media")
    .setStyle(ButtonStyle.Primary);

  const highBtn = new ButtonBuilder()
    .setCustomId(`ticket:setpriority:${channelId}:high`)
    .setLabel("Alta")
    .setStyle(ButtonStyle.Danger);

  const critBtn = new ButtonBuilder()
    .setCustomId(`ticket:setpriority:${channelId}:critical`)
    .setLabel("Critica")
    .setStyle(ButtonStyle.Danger);

  const row = new ActionRowBuilder<ButtonBuilder>()
    .addComponents(lowBtn, medBtn, highBtn, critBtn);

  return new ContainerBuilder()
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `## Cambiar Prioridad\nSelecciona la nueva prioridad para este ticket.`
          )
        )
        .setThumbnailAccessory(
          new ThumbnailBuilder().setURL(avatarUrl)
        )
    )
    .addSeparatorComponents(
      new SeparatorBuilder()
        .setSpacing(SeparatorSpacingSize.Small)
        .setDivider(true)
    )
    .addActionRowComponents(row)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `-# MEXERP System · ${getFooterTimestamp()}`
      )
    );
}

// ─── CONTAINER DE ESTADISTICAS ────────────────────────────────────────────────
export function buildStatsContainer(
  stats: Array<{
    userTag: string;
    totalClaimed: number;
    totalClosed: number;
    totalTranscripts: number;
  }>,
  client: Client,
): ContainerBuilder {
  const avatarUrl = client.user?.displayAvatarURL({ size: 256 }) ?? "";

  const rows = stats
    .map(
      (s, i) =>
        `**${i + 1}.** ${s.userTag} — Reclamados: **${s.totalClaimed}** · Cerrados: **${s.totalClosed}** · Transcripciones: **${s.totalTranscripts}**`
    )
    .join("\n");

  return new ContainerBuilder()
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `## Estadisticas del Staff\nRanking basado en actividad en tickets.`
          )
        )
        .setThumbnailAccessory(
          new ThumbnailBuilder().setURL(avatarUrl)
        )
    )
    .addSeparatorComponents(
      new SeparatorBuilder()
        .setSpacing(SeparatorSpacingSize.Small)
        .setDivider(true)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(rows || "Sin datos registrados.")
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `-# MEXERP System · ${getFooterTimestamp()}`
      )
    );
}

// ─── CONTAINER DE PERFIL STAFF (STATS REVISAR) ──────────────────────────────
export function buildStaffProfileContainer(
  targetMember: import("discord.js").GuildMember,
  processedCount: number,
  client: Client,
): ContainerBuilder {
  const userAvatar = targetMember.user.displayAvatarURL({ size: 256 });

  const HIERARCHY_ROLES = [
    "1528876703450136737",
    "1528876795783282880",
    "1529312367706378341",
    "1529312300207443978",
    "1529322176757628970",
  ];

  const matchingRoleId = HIERARCHY_ROLES.find(roleId => targetMember.roles.cache.has(roleId));

  const rangoDisplay = matchingRoleId
    ? `<@&${matchingRoleId}>`
    : (targetMember.roles.highest && targetMember.roles.highest.id !== targetMember.guild.id
        ? `<@&${targetMember.roles.highest.id}>`
        : "Sin Rango");

  const joinedTimestamp = targetMember.joinedTimestamp
    ? Math.floor(targetMember.joinedTimestamp / 1000)
    : Math.floor(Date.now() / 1000);

  const headerText = [
    `# Perfil de <@${targetMember.id}>`,
    `**Staff:** <@${targetMember.id}> **(@${targetMember.user.username})**`,
    `**Fecha de Ingreso:** <t:${joinedTimestamp}:F>`,
    `**Rango:** ${rangoDisplay}`,
  ].join("\n");

  const ticketsText = `**Tickets Procesados:** ${processedCount}`;

  return new ContainerBuilder()
    .setAccentColor(getRandomColor())
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(headerText)
        )
        .setThumbnailAccessory(
          new ThumbnailBuilder().setURL(userAvatar)
        )
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(ticketsText)
    )
    .addSeparatorComponents(
      new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small).setDivider(true)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`-# MEXERP Staff · ${getFooterTimestamp()}`)
    );
}
